let menu=documnet .queryselector('#menu-icon');
let nabvbar=document.queryselector('.navbar');

menu.onclick=() =>{
    menu.classlist.toggle('bx-x');
    nabvbar.classlist.toggle('active');
}